﻿' The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

Imports Windows.ApplicationModel.Background
Imports Windows.Devices.Geolocation
Imports Windows.Storage
Imports Windows.Storage.Streams
Imports Windows.System
''' <summary>
''' An empty page that can be used on its own or navigated to within a Frame.
''' </summary>
Public NotInheritable Class MainPage
    Inherits Page

    Private Async Sub uiReadHist_Click(sender As Object, e As RoutedEventArgs)
        Dim rVal As GeolocationAccessStatus = Await Geolocator.RequestAccessAsync()
        If rVal <> GeolocationAccessStatus.Allowed Then Exit Sub

        Await App.WczytajHistorie()

        Dim dTime = App.miSecs / 3600   ' sekundy -> godziny
        Dim dDistance = CInt(App.mdMeters / 1000)

        uiDistance.Text = "Daily distance = " & dDistance & " km"
        If dTime > 0 Then
            uiSpeed.Text = "Average speed = " & CInt(dDistance / dTime) & " km/h"
        Else
            uiSpeed.Text = " "
        End If
        uiPoints.Text = "Points: " & App.miPoints & "/" & App.miPointsTotal

        ' Windows.UI.Xaml.Controls.Maps.MapPolyline
    End Sub

    Private Async Sub uiSave_Click(sender As Object, e As RoutedEventArgs)
        Dim rVal As GeolocationAccessStatus = Await Geolocator.RequestAccessAsync()
        If rVal <> GeolocationAccessStatus.Allowed Then Exit Sub

        uiSave.IsEnabled = False
        App.SaveGPX()
        uiSave.IsEnabled = True

    End Sub
    Private Async Sub RegisterUserTrigger(Optional bOnlyDel As Boolean = False)

        For Each oTask In BackgroundTaskRegistration.AllTasks
            If oTask.Value.Name = "DailyItinerary_User" Then oTask.Value.Unregister(True)
        Next

        If bOnlyDel Then Exit Sub

        Dim rVal As GeolocationAccessStatus = Await Geolocator.RequestAccessAsync()
        If rVal <> GeolocationAccessStatus.Allowed Then Exit Sub

        Dim oBAS As BackgroundAccessStatus
        oBAS = Await BackgroundExecutionManager.RequestAccessAsync()

        If oBAS = BackgroundAccessStatus.AlwaysAllowed Or oBAS = BackgroundAccessStatus.AllowedSubjectToSystemPolicy Then
            ' https://docs.microsoft.com/en-us/windows/uwp/launch-resume/create-And-register-an-inproc-background-task
            Dim builder As BackgroundTaskBuilder = New BackgroundTaskBuilder
            Dim oRet As BackgroundTaskRegistration

            builder.SetTrigger(New SystemTrigger(SystemTriggerType.UserPresent, False))
            builder.Name = "DailyItinerary_User"
            oRet = builder.Register()
        End If

    End Sub
    Private Sub uiLiveTile_Click(sender As Object, e As RoutedEventArgs) Handles uiLiveTile.Click
        App.SetSettingsBool("liveTile", uiLiveTile.IsChecked)
        If uiLiveTile.IsChecked Then
            ' zarejestruj event
            RegisterUserTrigger()
        Else
            ' wyrejestruj event
            RegisterUserTrigger(True)
        End If
    End Sub

    Private Async Sub uiAutoSave_Click(sender As Object, e As RoutedEventArgs) Handles uiAutoSave.Click
        App.SetSettingsBool("autoSave", uiAutoSave.IsChecked)
        If uiAutoSave.IsChecked Then
            ' zarejestruj event
            Await App.DodajTriggerPolnocny()
        Else
            ' wyrejestruj event
            For Each oTask In BackgroundTaskRegistration.AllTasks
                If oTask.Value.Name = "DailyItinerary_Daily" Then oTask.Value.Unregister(True)
            Next
        End If
    End Sub

    Private Async Sub uiRate_Click(sender As Object, e As RoutedEventArgs)
        Dim sUri As New Uri("ms-windows-store://review/?PFN=" & Package.Current.Id.FamilyName)
        Await Launcher.LaunchUriAsync(sUri)
    End Sub

    Private Async Sub uiPage_GotFocus(sender As Object, e As RoutedEventArgs)
        ' to musi byc z UIthread!
        Dim rVal As GeolocationAccessStatus = Await Geolocator.RequestAccessAsync()
        If rVal <> GeolocationAccessStatus.Allowed Then
            Await App.AddLogLine("uiPage_GotFocus: no allowed geolocation")
            Exit Sub
        End If

        uiReadHist_Click(Nothing, Nothing)
        uiLiveTile.IsChecked = App.GetSettingsBool("liveTile")
        uiAutoSave.IsChecked = App.GetSettingsBool("autoSave")
        If App.GetSettingsBool("autoSave") Then Await App.DodajTriggerPolnocny()
        If App.GetSettingsBool("liveTile") Then RegisterUserTrigger()
    End Sub

    Private Async Sub uiAdd_Click(sender As Object, e As RoutedEventArgs) Handles uiAdd.Click
        Dim rVal As GeolocationAccessStatus = Await Geolocator.RequestAccessAsync()
        If rVal <> GeolocationAccessStatus.Allowed Then Exit Sub

        Dim oDevGPS = New Geolocator()

        Dim oPos As Geoposition
        oDevGPS.DesiredAccuracyInMeters = 200
        Dim oCacheTime = New TimeSpan(0, 1, 0)
        Dim oTimeout = New TimeSpan(0, 0, 15)    ' timeout 

        Try
            oPos = Await oDevGPS.GetGeopositionAsync(oCacheTime, oTimeout)
        Catch ex As Exception   ' zapewne timeout
        End Try

    End Sub


    Private Sub uiLogReset_Click(sender As Object, e As RoutedEventArgs)
        App.msLog = ""
    End Sub

    Private Sub uiLog_Show(sender As Object, e As RoutedEventArgs)
        App.MsgBox(App.msLog)
    End Sub
End Class
